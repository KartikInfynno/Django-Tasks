from django.contrib.auth.forms import UsernameField
from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, render
from django.urls import reverse
from django.contrib.auth import authenticate, login as login_new, logout
from django.contrib.auth.decorators import login_required
from fund_provider.models import Provider_Details

from fund_recipient.models import Company
from .forms import RegistrationForm, LoginForm
from django.contrib import messages

def login_view(request):
    form = LoginForm()
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username= username, password= password)

        if user is not None:
            login_new(request, user)
            if user.user_type == 'Fund Recipient':
                if Company.objects.filter(user=request.user).exists():
                    return redirect('recipient')
                
                else:
                    return redirect('create_comp')
            if Provider_Details.objects.filter(name = request.user).exists():
                    return redirect('provider')
            else:
                return redirect('create_profile')

        else:
            return render(request, 'apps/auths/login.html', {
                "message" : "Invalid Credentials"
            })
    return render(request, 'apps/auths/login.html', {'form' : form})

def auth_register(request):
    form = RegistrationForm()
    if request.method == 'POST':
        form = RegistrationForm(request.POST)

        if form.is_valid():
            form.save()
            messages.success(request, 'Account Created Successfully Please Login to proceed')
            return redirect('login')

    return render(request, 'apps/auths/register.html', {'form' : form })

@login_required(login_url='login')
def auth_logout(request):
    logout(request)
    return redirect('index')
  
# def register_view(request):
#     if request.method == "POST":
#         username = request.POST["username"]
#         email = request.POST["email"]

#         # Ensure password matches confirmation
#         password = request.POST["password"]
#         confirmation = request.POST["confirmation"]
#         if password != confirmation:
#             return render(request, "users/register.html", {
#                 "message": "Passwords must match."
#             })

#         elif password is None:
#             return render(request, "users/register.html", {
#                 "message": "Please Enter Password"
#             })

#         # Attempt to create new user
#         try:
#             user = User.objects.create_user(username, email, password)
#             # print(user)
#             user.save()
#         except IntegrityError:
#             return render(request, "users/register.html", {
#                 "message": "Username already taken."
#             })
#         login_new(request, user)
#         # subject = "Welcome to testing Email"
#         # message = f"Hi {username}, thank you for registering with us."
#         # email_from = settings.EMAIL_HOST_USER
#         # recipient_list = (email,)
#         # send_mail(subject, message, email_from, recipient_list, fail_silently=False)
#         return HttpResponseRedirect(reverse("index"))
#     else:
#         return render(request, "users/register.html") 