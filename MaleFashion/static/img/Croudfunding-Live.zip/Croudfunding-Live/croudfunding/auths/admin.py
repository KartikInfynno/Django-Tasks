from django.contrib import admin
from .models import FundUser

admin.site.register(FundUser)