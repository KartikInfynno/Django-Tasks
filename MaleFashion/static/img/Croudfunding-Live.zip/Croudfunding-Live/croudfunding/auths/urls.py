from django.urls import path,include
from . import views


urlpatterns = [
    path('register/',views.auth_register,name='register'),
    path('login/', views.login_view,name='login'),
    path('logout/', views.auth_logout,name='logout'),
]