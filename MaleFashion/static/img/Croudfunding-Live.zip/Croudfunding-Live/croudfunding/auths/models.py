from django.db import models
from django.contrib.auth.models import AbstractUser

class FundUser(AbstractUser):

    user_choice = (
        ('Fund Provider', 'Fund Provider'),
        ('Fund Recipient', 'Fund Recipient'),
    )

    user_type = models.CharField(choices= user_choice, default= 'Fund Provider', max_length= 128)