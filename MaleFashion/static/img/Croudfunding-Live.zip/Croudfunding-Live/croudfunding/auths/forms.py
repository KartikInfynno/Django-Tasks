from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.forms import fields, widgets
from .models import FundUser

class RegistrationForm(UserCreationForm):

    class Meta:
        model = FundUser
        fields = ['username', 'email', 'password1', 'password2', 'user_type']

        widgets = {
            'username' : forms.TextInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Enter Username'}),
            'email' : forms.EmailInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Enter Email'}),
            'password1' : forms.PasswordInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Enter Password'}),
            'password2' : forms.PasswordInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Confirm Password'}),
            'user_type' : forms.Select(attrs={'class': 'form-control form-control-lg','placeholder' : 'Account Type'}),
        }
class LoginForm(AuthenticationForm):
    pass