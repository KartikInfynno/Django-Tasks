from django import forms
from django import forms
from .models import Payment_Details, Provider_Details

class Profile_form(forms.ModelForm):
    class Meta:
        model = Provider_Details
        # fields = '__all__'
        exclude = ['name']
        fields =  ['full_name','email_address','phone_number','addr1','addr2','city','state','pin_code','country','profile_pic']
        widgets = {
            'full_name' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
            'email_address' : forms.EmailInput(attrs={'class': 'form-control form-control-lg'}),
            'phone_number' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
            'addr1' : forms.Textarea(attrs={'class': 'form-control form-control-lg'}),
            'addr2' : forms.Textarea(attrs={'class': 'form-control form-control'}),
            'city' : forms.TextInput(attrs={'class': 'form-control form-control'}),
            'state' : forms.TextInput(attrs={'class': 'form-control form-control'}),
            'pin_code' : forms.TextInput(attrs={'class': 'form-control form-control'}),
            'country' : forms.TextInput(attrs={'class': 'form-control form-control'}),
            'profile_pic' : forms.widgets.ClearableFileInput(attrs={'class': 'form-control form-control-lg'}),
        }

class Payment_form(forms.ModelForm):
    class Meta:
        model = Payment_Details
        fields = ['name_on_card', 'card_number', 'expiry_date','cvv','amount']
        exclude = ['user','profile','project']
        widgets = {
            'name_on_card' : forms.TextInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Name On Card'}),
            'card_number' : forms.TextInput(attrs={'class': 'form-control form-control-lg', 'placeholder' : '0000 0000 0000 0000'}),
            'expiry_date' : forms.TextInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'DD/MM'}),
            'cvv' : forms.TextInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'CVV'}),
            'amount' : forms.TextInput(attrs={'class': 'form-control form-control-lg','placeholder' : 'Amount'}),
        }