from django.contrib import admin
from .models import Payment_Details, Provider_Details

admin.site.register(Provider_Details)
admin.site.register(Payment_Details)