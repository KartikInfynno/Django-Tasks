from django.urls import path
from . import views

urlpatterns = [
    path('provider/profile_creation/', views.profile, name='create_profile'),
    path('provider/<int:id>/payment/',views.payment, name= 'invest'),
    path('provider/<int:camp_id>/detail/',views.detail, name='p_detail'),
    path('provider/p_portfolio/', views.invest, name = 'portfolio'),
    path('provider/about-us/', views.about_us, name = 'p_aboutus')
]