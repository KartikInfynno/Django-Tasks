from django.shortcuts import redirect, render
from auths.models import FundUser
from fund_recipient.models import Add_Project
from .models import Payment_Details, Provider_Details
from .forms import Payment_form, Profile_form
from django.contrib.auth.decorators import login_required

# def provide_fund(request,camp_id):
#     donate = Add_Project.objects.get(pk=camp_id)
#     form = Provider_form()

def profile(request):
    form = Profile_form()
    user = request.user
    if request.method == 'POST':
        form = Profile_form(request.POST)
        if form.is_valid():
            cd = FundUser.objects.get(pk= request.user.id)
            user = form.save(commit=False)
            user.name = cd 
            user.save()

            return redirect('provider')

    return render(request,'apps/fund_provider/profile_form.html',{'form' : form})


def payment(request,id):
    form = Payment_form()
    
    

    if request.method == 'POST':
        form = Payment_form(request.POST)
        user = FundUser.objects.get(pk=request.user.id)
        profile = Provider_Details.objects.get(name=user)
        project = Add_Project.objects.get(id=id)

        if form.is_valid():
            form = form.save(commit=False)
            form.user = user
            form.profile = profile
            form.project = project
            form.save()
            return redirect('provider')
            
    return render(request,'apps/fund_provider/payment.html', { 'form' : form })
    
def invest(request):
    provide = Payment_Details.objects.filter(user = request.user)
    
    context = {
        'provide' : provide
    }
    return render(request,'apps/fund_provider/doctors-dashboard.html', context=context)

@login_required(login_url='login')
def detail(request, camp_id):
    detail = Add_Project.objects.get(pk=camp_id)
    context = {
        'details': detail
    }
    return render(request, "apps/fund_provider/details.html", context=context)

def about_us(request):
    return render(request,'apps/base_app/about.html')