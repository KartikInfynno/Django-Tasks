from django.db import models
from auths.models import FundUser
from fund_recipient.models import Add_Project

# PAY_TYPES = (
# 		('CC', 'Credit Card'),
#         ('DC', 'DEBIT Card'),
# 		('BC', 'Bitcoin'),
# 		('PP', 'PayPal'),
# 		('BT', 'Bank Transfer'),
# 	)

class Provider_Details(models.Model):
    
    name = models.OneToOneField(FundUser, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=255)
    email_address = models.EmailField(max_length=255)
    phone_number = models.IntegerField()
    addr1 = models.CharField(max_length=255)
    addr2 = models.CharField(max_length=255)
    city = models.CharField(max_length=255)
    state = models.CharField(max_length=255)
    pin_code = models.IntegerField()
    country = models.CharField(max_length=255)
    profile_pic = models.ImageField(upload_to= 'Profile_pic',blank=  True, null= True)

    def __str__(self):
        return self.full_name

class Payment_Details(models.Model):

    user = models.ForeignKey(FundUser, on_delete=models.CASCADE)
    project = models.ForeignKey(Add_Project,on_delete=models.CASCADE)
    profile = models.ForeignKey(Provider_Details, on_delete=models.CASCADE)
    name_on_card = models.CharField(max_length=255)
    card_number = models.IntegerField(null=True, blank= True)
    expiry_date = models.CharField(max_length=255,null=True, blank= True)
    cvv = models.IntegerField(null=True, blank= True)
    amount = models.CharField(max_length=255)
    date = models.DateField(auto_now_add=True)
    