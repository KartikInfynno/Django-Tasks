from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('recipient/', views.recipient_index, name='recipient'),
    path('provider/', views.provider_index, name='provider'),
    path('about/',views.about_us, name='about')
]