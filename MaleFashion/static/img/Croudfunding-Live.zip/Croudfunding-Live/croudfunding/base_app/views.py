from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from auths.models import FundUser
from fund_recipient.models import Add_Project, Company


def index(request):
    proj = Add_Project.objects.all()
    comp = Company.objects.all()
    return render(request, 'apps/base_app/index.html', { "proj" : proj ,
                                                          "comp" : comp })

@login_required(login_url='login')
def recipient_index(request):
    u = FundUser.objects.get(pk=request.user.id)
    print(u)
    comp = Company.objects.get(user=u)
    print(comp)
    proj = comp.Comp.all()
    return render(request, 'apps/fund_recipient/recipient.html' ,{'proj':proj})

@login_required(login_url='login')
def provider_index(request):
    proj = Add_Project.objects.all()
    return render(request, 'apps/fund_provider/provider.html',{ "proj" : proj })

def about_us(request):
    return render(request,'apps/base_app/about.html')