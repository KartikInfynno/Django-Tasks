import imp
from django.contrib.auth.models import update_last_login
from django.db import models
from auths.models import FundUser
import datetime

class Company(models.Model):
    
    user = models.OneToOneField(FundUser, on_delete=models.CASCADE, related_name='companies')
    company_name = models.CharField(max_length=128)
    company_logo = models.ImageField(upload_to= 'Company Logo',blank= True, null= True)
    company_address = models.CharField(max_length=128)

    def __str__(self):
        return f'{self.company_name}'

class Add_Project(models.Model):

    category = (
        ('Art', 'Art'),
        ('Comic', 'Comic'),
        ('Craft', 'Craft'),
        ('Design', 'Design'),
        ('Film & Video', 'Film & Video'),
        ('Games', 'Games'),
        ('Music', 'Music'),
        ('Photography', 'Photography'),
        ('Technology', 'Technology'),
    )
    
    user = models.ForeignKey(FundUser,on_delete=models.CASCADE)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, default= 1, related_name='Comp')
    company_email = models.EmailField(max_length= 64)
    project_title = models.CharField(max_length= 64)
    ptoject_tagline = models.CharField(max_length= 128)
    project_category = models.CharField(choices=category, max_length=248)
    project_description = models.CharField(max_length= 1000)
    project_start_date = models.DateTimeField(auto_now_add= True)
    project_campaign_card = models.ImageField(upload_to= 'Team_Campaign_Cards',blank=  True, null= True)
    project_demo_video = models.FileField(upload_to= 'Team_project_videos', blank=True, null= True)

    fund_type = (
        ('INR','INR'),
        ('USD','USD'),
        ('EURO','EURO'),
    )

    funding_type = models.CharField(choices=fund_type, default= 'INR', max_length=128)

    duration = (
        ('Immediately', 'Immediately'),
        ('1-3 Months', '1-3 Months'),
        ('3+ Months', '3+ Months'), 
    )

    funding_duration = models.CharField(choices=duration, max_length= 128)
    fundng_startdate = models.DateTimeField(auto_now_add=True)
    funding_enddate = models.DateField(auto_now=False, auto_now_add=False)
    

    def __str__(self):
        return f'{self.project_title}'
