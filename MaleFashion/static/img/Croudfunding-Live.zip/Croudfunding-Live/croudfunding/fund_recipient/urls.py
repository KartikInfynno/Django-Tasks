from django.urls import path,include
from . import views

urlpatterns = [
    path('recipient/create_camp/', views.start_campaign, name='create_camp'),
    path('recipient/create_comp/', views.start_company, name= 'create_comp'),
    path('recipient/myprojects/', views.my_projects, name= 'view_projects'),
    path('recipient/<int:camp_id>/detail/', views.detail, name='r_detail'),
    path('recipient/portfolio/', views.portflio, name= 'r_portfolio'),
    path('recipient/about-us/', views.about_us, name = 'r_aboutus')
]