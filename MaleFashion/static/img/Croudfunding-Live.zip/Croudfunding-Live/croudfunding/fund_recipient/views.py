from django.shortcuts import render,redirect

from fund_provider.models import Payment_Details, Provider_Details
from .forms import StartCamp,StartCompany
from .models import Add_Project,Company
from django.contrib.auth.decorators import login_required
from auths.models import FundUser

@login_required(login_url='login')
def start_company(request):
    form = StartCompany
    user = request.user

    if request.method == 'POST':
         form = StartCompany(request.POST,request.FILES)
         user = request.user
         user = FundUser.objects.get(pk=request.user.id)

         if form.is_valid():
             img = form.cleaned_data.get('company_logo')

             form = form.save(commit=False)
             form.company_logo = img
             form.user= user
             form.save()
             return redirect('create_camp')

    return render(request, 'apps/fund_recipient/start_company.html', { 'form' : form })

@login_required(login_url='login')
def start_campaign(request):
    form = StartCamp()
    user = request.user

    if request.method == 'POST':
        form = StartCamp(request.POST,request.FILES)
        user = request.user
        user = FundUser.objects.get(pk=request.user.id)


        if form.is_valid():
            img = form.cleaned_data.get('project_campaign_card')
            vid = form.cleaned_data.get('project_demo_video')
            cd = Company.objects.get(user=request.user.id)

            form = form.save(commit=False)
            print(cd)
            form.company = cd
            form.project_campaign_card = img
            form.project_demo_video = vid
            form.user = user
            form.save()
            return redirect('recipient')

    return render(request, 'apps/fund_recipient/start_campaign.html', { 'form' : form })



@login_required(login_url='login')
def detail(request, camp_id):
    detail = Add_Project.objects.get(pk=camp_id)
    context = {
        'details': detail
    }
    return render(request, "apps/fund_recipient/details.html", context=context)


def my_projects(request):
    my_proj = Add_Project.objects.filter(user= request.user)
    return render(request, "apps/fund_recipient/myprojects.html", {'myproj' : my_proj})

def portflio(request):
    donations = Add_Project.objects.filter(user= request.user)
    all_donations = Payment_Details.objects.filter(project__in = donations)
    company = Company.objects.filter(user= request.user)
    context = {
        'all_donations' : all_donations, 
        'company' : company
    }

    return render(request, "apps/fund_recipient/r_dashboard.html", context)

def about_us(request):
    return render(request,'apps/base_app/about.html')