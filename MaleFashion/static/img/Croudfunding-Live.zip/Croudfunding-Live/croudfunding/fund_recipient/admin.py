from django.contrib import admin
from .models import Add_Project,Company

admin.site.register(Add_Project)
admin.site.register(Company)
