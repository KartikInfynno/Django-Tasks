from lzma import FORMAT_ALONE
from django import forms
from django import forms
from .models import Add_Project,Company
from django.contrib.admin.widgets import AdminDateWidget


# CHOICES_CATEGORIES = (
#     ('Art', 'Art'),
#     ('Comic', 'Comic'),
#     ('Craft', 'Craft'),
#     ('Design', 'Design'),
#     ('Film & Video', 'Film & Video'),
#     ('Games', 'Games'),
#     ('Music', 'Music'),
#     ('Photography', 'Photography'),
#     ('Technology', 'Technology'),
# )

class StartCamp(forms.ModelForm):
    # project_category = forms.ChoiceField(choices= CHOICES_CATEGORIES, widget=forms.widgets.Select)
    # funding_enddate : forms.DateInput(widget=forms.widgets.DateInput(attrs={'type': 'date', 'class': 'form-control form-control-lg'}))
    class Meta:
        model = Add_Project
        # fields = '__all__'
        exclude = ['company','user']
        fields =  ['project_title','company_email','project_category','ptoject_tagline','project_description','project_campaign_card','project_demo_video','funding_type','funding_duration','funding_enddate']
        widgets = {
            'project_title' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
            'company_email' : forms.EmailInput(attrs={'class': 'form-control form-control-lg'}),
            'ptoject_tagline' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
            'project_category' : forms.Select(attrs={'class': 'form-control form-control-lg'}),
            'project_description' : forms.Textarea(attrs={'class': 'form-control form-control'}),
            'project_campaign_card' : forms.widgets.ClearableFileInput(attrs={'class': 'form-control form-control-lg'}),
            'project_demo_video' : forms.widgets.ClearableFileInput(attrs={'class': 'form-control form-control-lg'}),
            'funding_type' : forms.Select(attrs={'class': 'form-control form-control-lg'}),
            'funding_duration' : forms.Select(attrs={'class': 'form-control form-control-lg'}),
            'funding_enddate' : forms.DateInput(attrs={'class':'form-control form-control-lg', 'id':'datepicker'})
        }

class StartCompany(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['company_name','company_address','company_logo']
        exclude = ['user']
        widgets = {
            'company_name' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
            'company_logo' : forms.widgets.ClearableFileInput(attrs={'class': 'form-control form-control-lg'}),
            'company_address' : forms.TextInput(attrs={'class': 'form-control form-control-lg'}),
        }